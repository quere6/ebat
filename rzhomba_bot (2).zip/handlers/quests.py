# handlers/quests.py
