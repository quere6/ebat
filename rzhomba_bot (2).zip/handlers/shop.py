# handlers/shop.py
